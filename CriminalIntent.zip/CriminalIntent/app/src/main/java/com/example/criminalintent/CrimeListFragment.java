package com.example.criminalintent;

import androidx.fragment.app.Fragment;

public class CrimeListFragment extends Fragment {
}
